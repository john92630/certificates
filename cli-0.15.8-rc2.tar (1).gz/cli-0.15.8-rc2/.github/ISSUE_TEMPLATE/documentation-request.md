---
name: Documentation Request
about: Request documentation for a feature
title: ''
labels: docs, needs triage
assignees: ''

---

<!---
Tell us which feature you'd like to see documented. 
 - Where would you like that documentation to live (command line usage output, website, github markdown on the repo)? 
- If there are specific attributes or options you'd like to see documented, please include those in the request.
-->
