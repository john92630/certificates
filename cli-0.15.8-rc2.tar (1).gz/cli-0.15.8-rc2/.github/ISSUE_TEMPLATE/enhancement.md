---
name: CLI Enhancement
about: Suggest an enhancement to step cli
title: ''
labels: enhancement, needs triage
assignees: ''

---

### What would you like to be added


### Why this is needed
